export default [
  require("E:\\Users\\Zhang\\Desktop\\Test\\my-website\\node_modules\\infima\\dist\\css\\default\\default.css"),
  require("E:\\Users\\Zhang\\Desktop\\Test\\my-website\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages"),
  require("E:\\Users\\Zhang\\Desktop\\Test\\my-website\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress"),
  require("E:\\Users\\Zhang\\Desktop\\Test\\my-website\\src\\css\\custom.css"),
];
